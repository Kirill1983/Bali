package org.kkonoplev.bali.classifyreport;

public class BaseA {
	
	protected String str;

	public BaseA(String str) {
		super();
		this.str = str;
	}

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	
}
