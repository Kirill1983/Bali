package org.kkonoplev.bali.classifyreport;

import java.util.List;

public class BoxBase {
	
	private List<BaseA> baseA;
	private  BaseA a;
	
	public BoxBase(List<BaseA> baseA, BaseA a) {
		super();
		this.baseA = baseA;
		this.a = a;
	}
	
	

}
