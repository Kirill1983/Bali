package org.kkonoplev.bali.runner;

public interface ProjectRunner {
	
	public void run(RunnableItem runnableItem) throws Exception;

}
