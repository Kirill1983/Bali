package org.kkonoplev.bali.classifyreport.model.artifact;

public interface ResultDirArtifact {
	
	public void addNodeUrlPath(String str);

}
