package org.kkonoplev.bali.classifyreport;

public class AnchorB extends BaseA {
	
	public AnchorB(String newVar, String str) {
		super(str);
		this.newVarB = newVar;
	}
	
	public String newVarB = "";

	public String getNewVarB() {
		return newVarB;
	}

	public void setNewVarB(String newVarB) {
		this.newVarB = newVarB;
	}
	
	
	
}
