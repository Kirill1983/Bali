package org.kkonoplev.bali.classifyreport.model.artifact;

import java.io.Serializable;

public class WarningCaseArtifact implements Serializable {
	
	public WarningCaseArtifact(){
	}
	
	public  String toJSON(){
		return "";
	}

}
