package org.kkonoplev.bali.services;

public class CommunityEdition {
	
	public static int MAX_THREADS = 10;
	public static int MAX_SUITES = 10;
	
	public static boolean isEnabled(){
		return false;
	}


}
