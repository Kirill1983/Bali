package org.kkonoplev.bali.classifyreport.model;

public enum WarningCaseDataType {
	
	HREF,
	IMG,
	TEXT;
	

}
